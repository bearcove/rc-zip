# rc-zip

This is the core rc-zip crate, containing types, parses, and state machines,
and that doesn't do any I/O by itself.

The full README for this crate is the [top-level README](../README.md) in this
repository.
