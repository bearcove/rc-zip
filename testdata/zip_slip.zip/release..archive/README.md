zip slip: in-component payload
